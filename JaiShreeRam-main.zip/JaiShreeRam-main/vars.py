# Sanjay Kagra 
# Add your details here and then deploy by clicking on HEROKU Deploy button
import os

API_ID    = os.environ.get("API_ID", "24495656")
API_HASH  = os.environ.get("API_HASH", "61afcf68c6429714dd18acd07f246571")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "7847799213:AAGhkL3RhRedZpopQDNBIrIdfFc7kkQMNxw") 

#WEBHOOK = True  # Don't change this
#PORT = int(os.environ.get("PORT", 8080))  # Default to 8000 if not set

